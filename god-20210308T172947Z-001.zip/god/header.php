<?php
include('config.php');
session_start();
date_default_timezone_set('Asia/Kolkata');
?>
<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
<link rel="icon" href="images/favicon.ico" type="image/ico">
<title>GOD</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
<link rel="stylesheet" href="css/flexslider.css" type="text/css" media="all" />
<link type="text/css" rel="stylesheet" href="http://www.dreamtemplate.com/dreamcodes/tabs/css/tsc_tabs.css" />
<link rel="stylesheet" href="css/tsc_tabs.css" type="text/css" media="all" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src='js/jquery.color-RGBa-patch.js'></script>
<script src='js/example.js'></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="css/lightGallery.css" type="text/css" media="all" />
<!-- //gallery -->
<!-- font-awesome icons -->
<link href="css/font-awesome.css" rel="stylesheet"> 

<!-- //font-awesome icons -->
<link href="//fonts.googleapis.com/css?family=Questrial" rel="stylesheet">
<link href="//fonts.googleapis.com/css?family=Jura:300,400,500,600" rel="stylesheet">
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<link rel="stylesheet" href="css/lightGallery.css" type="text/css" media="all" />
<!-- //gallery -->
<link rel="stylesheet" href="css/lightGallery.css" type="text/css" media="all" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta content="text/html; charset=iso-8859-2" http-equiv="Content-Type">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<style>
.mySlides {display:none;}
</style>
</head>
<body>
<!---div class="header">
	<div class="header-top">
		<div class="wrap">
			<div class="h-logo">
			<a href="index.php"><img src="images\logo.png" alt=""/></a>
			
		</div>--->
		
		<div class="header">
		
		<style>
	img 
	{
	  display: block;
	  margin-left: auto;
	  margin-right: auto;
	}
</style>
			<div><h1><a href="index.php"><img src="images\logo.png" class="center" alt=""/></a></h1>
		</div>
			<div class="w3layouts_header_left">
					<div class="top-nav-text">
							
					</div>
			</div>
		
			  <!---search box--->
			  <div class="block">
				<div class="w3layouts_header_right">
					
					<form action="process_search.php" id="reservation-form" method="post" onsubmit="myFunction()">
						   <fieldset>
							<div class="field" >
							
									 
											<input type="text" placeholder="Search Games Here..." style="height:27px;width:500px"  required id="search111" name="search">
											
											<input type="submit" value="Search" style="height:28px;padding-top:4px" id="button111">
							</div>       	

						   </fieldset>
						</form>
						<div class="clear"></div>
			   </div>
			</div>
			<!---<div class="nav-wrap">--->		
				<div class="collapse navbar-collapse navbar-left" id="bs-example-navbar-collapse-1">
					<nav class="cl-effect-5" id="cl-effect-5">
						<ul class="nav navbar-nav">
			           <li><a href="index.php"><span data-hover="Home">Home</span></a></li>
			  		   <li><a href="movies_events.php"><span data-hover="Games">Games</a></li>
			  		   <li><?php if(isset($_SESSION['user'])){
			  		   $us=mysqli_query($con,"select * from tbl_registration where user_id='".$_SESSION['user']."'");
        $user=mysqli_fetch_array($us);?><a href="profile.php"><span data-hover="Login"><?php echo $user['name'];?></a><a href="logout.php">Logout</a><?php }else{?><a href="login.php">Login</a><?php }?></li>
						<li><a href="#work" class="scroll"><span data-hover="Gallery">Gallery</span></a></li>
						</ul>
					</nav>
				</div>
 			<div class="clear"></div>
			
   		</div>
    
     			<div class="clear"></div>
				

   	

	<div class="banner">
		<div class="slider">
			<div class="callbacks_container">
			
				<img class="mySlides" src="images/banner1.jpg" class="img-responsive" style="width:100%">
				<!--div class="slider-info">
								
					<h4>Dragon Fin Soup Ridding </h4>
					 <p>World building is component of fantasy </p>
					<a href="#about" class="hvr-shutter-in-horizontal scroll">Read More</a>
				</div>---->
			
				 <img class="mySlides" src="images/banner2.jpg" class="img-responsive" style="width:100%">
				 <img class="mySlides" src="images/banner3.jpg" class="img-responsive" style="width:100%">
				 <img class="mySlides" src="images/banner4.jpg" class="img-responsive" style="width:100%">
				 <img class="mySlides" src="images/banner5.jpg" class="img-responsive" style="width:100%">
				 <img class="mySlides" src="images/banner6.jpg" class="img-responsive" style="width:100%">
			</div>
		</div>
	</div>

<script>
	var myIndex = 0;
	carousel();

	function carousel() {
	  var i;
	  var x = document.getElementsByClassName("mySlides");
	  for (i = 0; i < x.length; i++) {
		x[i].style.display = "none";  
	  }
	  myIndex++;
	  if (myIndex > x.length) {myIndex = 1}    
	  x[myIndex-1].style.display = "block";  
	  setTimeout(carousel, 5000); // Change image every 2 seconds
}
</script>
<script>
function myFunction() 
{
     if($('#hero-demo').val()=="")
        {
            alert("Please enter movie name");
            return false;
        }
    else{
        return true;
		}
    </script>
}